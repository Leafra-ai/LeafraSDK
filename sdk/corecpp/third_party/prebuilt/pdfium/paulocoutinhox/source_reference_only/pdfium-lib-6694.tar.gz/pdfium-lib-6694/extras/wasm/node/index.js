import pdfium from './pdfium.js';
import pdfiumModule from './pdfium.wasm';
