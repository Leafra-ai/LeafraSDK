---
name: Other type
about: Other issue type not related to bug or feature.
title: ''
labels: ''
assignees: ''

---


