---
layout: default
title: Java Setup
parent: Setup for Contributors
has_children: true
---

<!--
© 2016 and later: Unicode, Inc. and others.
License & terms of use: http://www.unicode.org/copyright.html
-->

# Java Setup


