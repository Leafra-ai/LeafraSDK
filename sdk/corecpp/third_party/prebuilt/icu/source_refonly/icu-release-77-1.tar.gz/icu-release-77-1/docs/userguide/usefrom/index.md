---
layout: default
title: Use From...
nav_order: 1700
has_children: true
---
<!--
© 2020 and later: Unicode, Inc. and others.
License & terms of use: http://www.unicode.org/copyright.html
-->

# Use From...

ICU4C can be used from other programming languages and environments. Please
refer to the subpages listed below for details.

* [How To Use ICU4C From COBOL](cobol.md)
