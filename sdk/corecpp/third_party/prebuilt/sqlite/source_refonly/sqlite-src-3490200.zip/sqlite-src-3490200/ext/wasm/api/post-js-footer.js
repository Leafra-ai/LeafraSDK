/* The current function scope was opened via post-js-header.js, which
   gets prepended to this at build-time. This file closes that
   scope. */
//console.warn("This is the end of the Module.runSQLite3PostLoadInit handler.");
}/*Module.runSQLite3PostLoadInit()*/;
//console.warn("This is the end of the setup of the (pending) Module.runSQLite3PostLoadInit");
